#include "Ili9341Display.hpp"
#include "MenuScreen.hpp"
#include "StartScreenEntity.hpp"
#include "TouchReader.hpp"

#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdio.h>

namespace {
constexpr char Tag[] = "ScreenCommunication";
constexpr uart_port_t MasterUart = UART_NUM_2;
constexpr int MasterTxPin = 22;
constexpr int MasterRxPin = 27;
constexpr int BaudRate = 115200;
constexpr size_t MasterReceiveBufferSize = 6144;
constexpr size_t MaxImageBytes = 40 * 1024;
constexpr TickType_t ImageStallTimeout = pdMS_TO_TICKS(3000);

char masterReceiveBuffer[MasterReceiveBufferSize];
size_t masterReceiveLength = 0;

// A card picture arrives as "CARD_IMAGE <bytes>\n" followed by that many raw bytes.
uint8_t* imageBuffer = nullptr;      // being filled (nullptr while skipping a picture)
size_t imageExpected = 0;
size_t imageReceived = 0;
TickType_t imageLastByteTick = 0;
uint8_t* receivedImage = nullptr;    // finished picture, owned by the main loop
size_t receivedImageLength = 0;

void freeReceivedImage()
{
    std::free(receivedImage);
    receivedImage = nullptr;
    receivedImageLength = 0;
}

void masterCommunicationInit()
{
    const uart_config_t config = {
        .baud_rate = BaudRate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ESP_ERROR_CHECK(uart_param_config(MasterUart, &config));
    ESP_ERROR_CHECK(
        uart_set_pin(MasterUart, MasterTxPin, MasterRxPin, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(MasterUart, 2048, 2048, 0, nullptr, 0));
}

void sendMasterCommand(const char* command)
{
    const size_t commandLength = std::strlen(command);
    ESP_LOGE(Tag, "TX command: %s", command);
    const int bytesWritten =
        uart_write_bytes(MasterUart, command, commandLength);
    if (bytesWritten != static_cast<int>(commandLength)) {
        ESP_LOGE(Tag, "Failed to send command");
        return;
    }
    ESP_ERROR_CHECK(uart_wait_tx_done(MasterUart, pdMS_TO_TICKS(100)));
}

enum class MasterEvent {
    None,
    AddCardDone,
    AddCardFailed,
    CardInfo,
    CardInfoFailed,
    CardImage,
    CardImageFailed,
    CardRemoved,
    CardRemoveFailed,
};

MasterEvent handleMasterLine(Ili9341Display& display, MenuScreen& menu)
{
    constexpr char collectionPrefix[] = "COLLECTION_LIST ";
    constexpr char infoPrefix[] = "CARD_INFO ";
    constexpr char imagePrefix[] = "CARD_IMAGE ";
    const char* line = masterReceiveBuffer;

    if (std::strncmp(line, infoPrefix, sizeof(infoPrefix) - 1) == 0) {
        menu.setCardInfo(line + sizeof(infoPrefix) - 1);
        return MasterEvent::CardInfo;
    }
    if (std::strncmp(line, "CARD_REMOVE_DONE", 16) == 0) {
        return MasterEvent::CardRemoved;
    }
    if (std::strncmp(line, "CARD_REMOVE_FAILED", 18) == 0) {
        return MasterEvent::CardRemoveFailed;
    }
    if (std::strncmp(line, "CARD_INFO_FAILED", 16) == 0) {
        return MasterEvent::CardInfoFailed;
    }
    if (std::strncmp(line, "CARD_IMAGE_FAILED", 17) == 0) {
        return MasterEvent::CardImageFailed;
    }
    if (std::strncmp(line, imagePrefix, sizeof(imagePrefix) - 1) == 0) {
        const long length = std::atol(line + sizeof(imagePrefix) - 1);
        if (length <= 0 || length > static_cast<long>(MaxImageBytes)) {
            ESP_LOGE(Tag, "Bad picture size %ld", length);
            return MasterEvent::CardImageFailed;
        }
        // If there is no memory the bytes are still read (and thrown away) so
        // they are not mistaken for text lines.
        imageBuffer = static_cast<uint8_t*>(std::malloc(static_cast<size_t>(length)));
        imageExpected = static_cast<size_t>(length);
        imageReceived = 0;
        imageLastByteTick = xTaskGetTickCount();
        return MasterEvent::None;
    }
    if (std::strstr(line, "ADD_CARD_DONE") != nullptr) {
        return MasterEvent::AddCardDone;
    }
    if (std::strstr(line, "ADD_CARD_FAILED") != nullptr) {
        return MasterEvent::AddCardFailed;
    }
    const char* response = std::strstr(line, collectionPrefix);
    if (response != nullptr) {
        ESP_LOGE(Tag, "COLLECTION_LIST matched, drawing");
        menu.drawCollection(display, response + sizeof(collectionPrefix) - 1);
    } else {
        ESP_LOGE(Tag, "line has no known prefix");
    }
    return MasterEvent::None;
}

MasterEvent receiveMasterData(Ili9341Display& display, MenuScreen& menu)
{
    MasterEvent event = MasterEvent::None;

    // A picture that stops arriving must not block the following messages.
    if (imageExpected > 0 && xTaskGetTickCount() - imageLastByteTick > ImageStallTimeout) {
        ESP_LOGE(Tag, "Picture transfer timed out (%u of %u bytes)",
                 (unsigned)imageReceived, (unsigned)imageExpected);
        std::free(imageBuffer);
        imageBuffer = nullptr;
        imageExpected = 0;
        event = MasterEvent::CardImageFailed;
    }

    // Read everything that is waiting, so a picture is taken in quickly.
    for (int round = 0; round < 64; ++round) {
        size_t available = 0;
        ESP_ERROR_CHECK(uart_get_buffered_data_len(MasterUart, &available));
        if (available == 0) {
            break;
        }

        uint8_t data[512];
        const size_t bytesToRead = available < sizeof(data) ? available : sizeof(data);
        const int bytesRead = uart_read_bytes(MasterUart, data, bytesToRead, 0);
        if (bytesRead <= 0) {
            break;
        }
        if (imageExpected == 0) {
            ESP_LOGE(Tag, "RX %d bytes", bytesRead);
        }

        for (int index = 0; index < bytesRead; ++index) {
            if (imageExpected > 0) {
                if (imageBuffer != nullptr) {
                    imageBuffer[imageReceived] = data[index];
                }
                ++imageReceived;
                imageLastByteTick = xTaskGetTickCount();
                if (imageReceived == imageExpected) {
                    freeReceivedImage();
                    receivedImage = imageBuffer;
                    receivedImageLength = imageExpected;
                    event = imageBuffer != nullptr ? MasterEvent::CardImage
                                                   : MasterEvent::CardImageFailed;
                    imageBuffer = nullptr;
                    imageExpected = 0;
                }
                continue;
            }

            const char character = static_cast<char>(data[index]);
            if (character == '\n') {
                masterReceiveBuffer[masterReceiveLength] = '\0';
                ESP_LOGE(Tag, "RX line (%u chars)", (unsigned)masterReceiveLength);
                const MasterEvent lineEvent = handleMasterLine(display, menu);
                if (lineEvent != MasterEvent::None) {
                    event = lineEvent;
                }
                masterReceiveLength = 0;
                continue;
            }
            if (masterReceiveLength < MasterReceiveBufferSize - 1) {
                masterReceiveBuffer[masterReceiveLength++] = character;
            } else {
                masterReceiveLength = 0;
                ESP_LOGE(Tag, "Master response exceeded receive buffer");
            }
        }
    }
    return event;
}

enum class CollectionView {
    List,         // the card names
    InfoLoading,  // waiting for the card's data
    DetailMenu,   // CARD / LEGALITIES / OTHER
    ImageLoading, // waiting for the picture
    RemoveConfirm, // "REMOVE CARD?" YES / NO
    Removing,     // waiting for the master to remove the card
    Card,
    Legalities,
    Other,
};

void sendCardCommand(const char* command, int cardNumber)
{
    char text[32];
    std::snprintf(text, sizeof(text), "%s %d\n", command, cardNumber);
    sendMasterCommand(text);
}
}

extern "C" void app_main(void) {
    constexpr int lcdMosi = 13;
    constexpr int lcdSclk = 14;
    constexpr int lcdCs = 15;
    constexpr int lcdDc = 2;
    constexpr int lcdRst = -1;
    constexpr int lcdBacklight = 21;

    masterCommunicationInit();

    Ili9341Display display(lcdMosi, lcdSclk, lcdCs, lcdDc, lcdRst, lcdBacklight);
    display.init();

    StartScreenEntity startScreen;
    display.fillScreen(display.rgb565(255, 255, 255));
    startScreen.draw(display);
    display.present();
    sendMasterCommand("IDLE\n");

    MenuScreen menu;
    // TPM408-2.8 / XPT2046 touch wiring.
    TouchReader touch(SPI3_HOST, GPIO_NUM_25, GPIO_NUM_32, GPIO_NUM_39,
                      GPIO_NUM_33, GPIO_NUM_36);
    touch.start();

    while (!touch.touched()) {
        receiveMasterData(display, menu);
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    touch.waitForRelease();

    menu.drawHome(display);
    sendMasterCommand("IDLE\n");
    int page = -1;
    int collectionPage = 0;
    CollectionView view = CollectionView::List;
    int selectedCard = -1;
    while (true) {
        const MasterEvent masterEvent = receiveMasterData(display, menu);
        if (page == 0 && (masterEvent == MasterEvent::AddCardDone ||
                          masterEvent == MasterEvent::AddCardFailed)) {
            // The master finished the ADD CARD job: back to the main menu.
            if (masterEvent == MasterEvent::AddCardFailed) {
                menu.drawPage(display, "FAILED");
                vTaskDelay(pdMS_TO_TICKS(1500));
            }
            page = -1;
            menu.drawHome(display);
            sendMasterCommand("IDLE\n");
            continue;
        }
        if (page == 1 && view == CollectionView::InfoLoading) {
            if (masterEvent == MasterEvent::CardInfo) {
                view = CollectionView::DetailMenu;
                menu.drawDetailMenu(display);
            } else if (masterEvent == MasterEvent::CardInfoFailed) {
                menu.drawPage(display, "NO DATA");
                vTaskDelay(pdMS_TO_TICKS(1500));
                view = CollectionView::List;
                menu.drawCollectionPage(display, collectionPage);
            }
        } else if (page == 1 && view == CollectionView::Removing &&
                   (masterEvent == MasterEvent::CardRemoved ||
                    masterEvent == MasterEvent::CardRemoveFailed)) {
            if (masterEvent == MasterEvent::CardRemoved) {
                // Back to the collection; ask for the list again so the card is gone.
                view = CollectionView::List;
                collectionPage = 0;
                selectedCard = -1;
                menu.drawCollectionLoading(display);
                sendMasterCommand("COLLECTION\n");
            } else {
                menu.drawPage(display, "FAILED");
                vTaskDelay(pdMS_TO_TICKS(1500));
                view = CollectionView::DetailMenu;
                menu.drawDetailMenu(display);
            }
        } else if (page == 1 && view == CollectionView::ImageLoading &&
                   (masterEvent == MasterEvent::CardImage ||
                    masterEvent == MasterEvent::CardImageFailed)) {
            // Without a picture the card screen still shows the oracle text.
            view = CollectionView::Card;
            menu.drawCardView(display,
                              masterEvent == MasterEvent::CardImage ? receivedImage : nullptr,
                              receivedImageLength);
        }
        if (receivedImage != nullptr) {
            freeReceivedImage();
        }

        if (!touch.touched()) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        const TouchReader::Point point = touch.readPoint();
        touch.waitForRelease();
        if (page < 0) {
            page = menu.hitTest(point.x, point.y);
            if (page >= 0) {
                static constexpr const char* labels[] = {
                    "ADD CARD", "COLLECTION", "DECKS"};
                static constexpr const char* commands[] = {
                    "ADD_CARD\n", "COLLECTION\n", "DECKS\n"};
                collectionPage = 0;
                view = CollectionView::List;
                menu.drawPage(display, labels[page]);
                if (page == 0) {
                    menu.drawAddCardLoading(display);
                } else if (page == 1) {
                    menu.drawCollectionLoading(display);
                }
                sendMasterCommand(commands[page]);
            }
        } else if (page == 1) {
            const bool back = menu.hitExit(point.x, point.y);
            switch (view) {
            case CollectionView::List:
                if (menu.hitCollectionPrevious(point.x, point.y)) {
                    if (collectionPage > 0) {
                        collectionPage = menu.drawCollectionPage(display, collectionPage - 1);
                    }
                } else if (menu.hitCollectionNext(point.x, point.y)) {
                    collectionPage = menu.drawCollectionPage(display, collectionPage + 1);
                } else if (back) {
                    page = -1;
                    collectionPage = 0;
                    menu.drawHome(display);
                    sendMasterCommand("IDLE\n");
                } else {
                    const int card = menu.hitCollectionRow(point.x, point.y, collectionPage);
                    if (card >= 0) {
                        selectedCard = card;
                        view = CollectionView::InfoLoading;
                        menu.drawDetailLoading(display);
                        sendCardCommand("CARD_INFO", selectedCard);
                    }
                }
                break;
            case CollectionView::InfoLoading:
                if (back) {
                    view = CollectionView::List;
                    menu.drawCollectionPage(display, collectionPage);
                }
                break;
            case CollectionView::DetailMenu:
                if (back) {
                    view = CollectionView::List;
                    menu.drawCollectionPage(display, collectionPage);
                } else {
                    const int button = menu.hitDetailButton(point.x, point.y);
                    if (button == 0) {
                        view = CollectionView::ImageLoading;
                        menu.drawDetailLoading(display);
                        sendCardCommand("CARD_IMAGE", selectedCard);
                    } else if (button == 1) {
                        view = CollectionView::Legalities;
                        menu.drawLegalities(display);
                    } else if (button == 2) {
                        view = CollectionView::Other;
                        menu.drawOther(display);
                    } else if (button == 3) {
                        view = CollectionView::RemoveConfirm;
                        menu.drawRemoveConfirm(display);
                    }
                }
                break;
            case CollectionView::RemoveConfirm: {
                const int choice = menu.hitRemoveConfirm(point.x, point.y);
                if (choice == 0) {
                    view = CollectionView::Removing;
                    menu.drawDetailLoading(display);
                    sendCardCommand("CARD_REMOVE", selectedCard);
                } else if (choice == 1) {
                    // NO: straight back to the collection menu.
                    view = CollectionView::List;
                    menu.drawCollectionPage(display, collectionPage);
                }
                break;
            }
            case CollectionView::Removing:
                // Wait for the master's answer; touches are ignored.
                break;
            case CollectionView::ImageLoading:
            case CollectionView::Card:
            case CollectionView::Legalities:
            case CollectionView::Other:
                if (back) {
                    view = CollectionView::DetailMenu;
                    menu.drawDetailMenu(display);
                }
                break;
            }
        } else if (menu.hitExit(point.x, point.y)) {
            page = -1;
            collectionPage = 0;
            menu.drawHome(display);
            sendMasterCommand("IDLE\n");
        }
    }
}
