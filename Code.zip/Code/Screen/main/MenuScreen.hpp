#pragma once

#include "Ili9341Display.hpp"

#include <cstddef>
#include <cstdint>
#include <string>

class MenuScreen {
public:
    void drawHome(Ili9341Display& display) const;
    void drawPage(Ili9341Display& display, const char* title) const;
    void drawCollectionLoading(Ili9341Display& display) const;
    void drawAddCardLoading(Ili9341Display& display) const;
    void drawCollection(Ili9341Display& display, const char* json);
    // Draws one page of the collection and returns the page that was shown
    // (the requested page is clamped to the number of pages).
    int drawCollectionPage(Ili9341Display& display, int page) const;

    // Details of one card. The Master sends the card as JSON; the views below
    // all draw from it.
    void setCardInfo(const char* json);
    void drawDetailLoading(Ili9341Display& display) const;
    void drawDetailMenu(Ili9341Display& display) const;
    // Returns false when the picture could not be decoded (a placeholder is drawn).
    bool drawCardView(Ili9341Display& display, const uint8_t* jpeg, size_t jpegLength) const;
    // "REMOVE CARD?" with the card's name and YES / NO buttons.
    void drawRemoveConfirm(Ili9341Display& display) const;
    void drawLegalities(Ili9341Display& display) const;
    void drawOther(Ili9341Display& display) const;

    int hitTest(int x, int y) const;
    // Number of the card whose row was touched on `page`, or -1.
    int hitCollectionRow(int x, int y, int page) const;
    // 0 = CARD, 1 = LEGALITIES, 2 = OTHER, 3 = REMOVE, -1 = none.
    int hitDetailButton(int x, int y) const;
    // 0 = YES, 1 = NO, -1 = none.
    int hitRemoveConfirm(int x, int y) const;
    bool hitExit(int x, int y) const;
    bool hitCollectionPrevious(int x, int y) const;
    bool hitCollectionNext(int x, int y) const;

private:
    void readerRect(Ili9341Display& display, int u, int v, int width, int height,
                    uint16_t color, bool fill) const;
    void readerLine(Ili9341Display& display, int u0, int v0, int u1, int v1,
                    uint16_t color) const;
    void readerText(Ili9341Display& display, const char* text, int u, int v,
                    uint16_t color, int scale) const;
    void drawExitButton(Ili9341Display& display, const char* label = "EXIT") const;
    void drawDetailTitle(Ili9341Display& display, const char* title) const;
    void drawRotatedText(Ili9341Display& display, const char* text,
                         int centerX, int centerY, uint16_t color) const;
    void drawGlyph(Ili9341Display& display, char character, int x, int y,
                   uint16_t color) const;
    void drawText(Ili9341Display& display, const char* text, int x, int y,
                  uint16_t color, int scale = 1) const;

    std::string collectionJson_;
    std::string cardInfoJson_;
    int collectionCount_ = 0;
};
