#pragma once

#include <cstddef>
#include <cstdint>

enum class DisplayRequest {
    Idle,
    Display,
    Collection,
    Cam,
    CardInfo,
    CardImage,
    CardRemove
};

void displayCommunicationInit();
bool displayCommunicationHasData();
DisplayRequest displayCommunicationReadRequest();
bool displayCommunicationSendCollectionList(const char* collectionListJson);
bool displayCommunicationSendAddCardResult(bool success);

// The card number that came with the last CardInfo / CardImage request.
int displayCommunicationReadArgument();
bool displayCommunicationSendCardInfo(const char* cardJson);
bool displayCommunicationSendCardInfoFailed();
bool displayCommunicationSendCardImage(const uint8_t* data, size_t length);
bool displayCommunicationSendCardImageFailed();
// Answer to a CardRemove request ("CARD_REMOVE_DONE" / "CARD_REMOVE_FAILED").
bool displayCommunicationSendCardRemoveResult(bool success);
