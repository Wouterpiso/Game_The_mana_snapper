#pragma once

#include <cstddef>
#include <cstdint>

// Looks a card up on Scryfall by (fuzzy) name and returns it as a JSON string
// in the same shape as the objects in collection.json.
//
// Returns nullptr when there is no network, no match, or the answer is invalid.
// The returned string must be released with apiFreeJson().
char* apiFetchCardByName(const char* cardName);
void apiFreeJson(char* json);

// Downloads `url` (at most `maxBytes`) and returns the raw bytes, or nullptr.
// Release with apiFreeBinary().
uint8_t* apiFetchBinary(const char* url, size_t maxBytes, size_t* length);
void apiFreeBinary(uint8_t* data);
