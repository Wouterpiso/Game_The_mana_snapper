#include "StateMachine.hpp"

#include "API.hpp"
#include "CamCommunication.hpp"
#include "Data.hpp"
#include "DisplayCommunication.hpp"
#include "ImageReconition.hpp"
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

// test_Image/test.jpeg, linked into the firmware by EMBED_FILES in main/CMakeLists.txt.
extern "C" const uint8_t testImageStart[] asm("_binary_test_jpeg_start");
extern "C" const uint8_t testImageEnd[] asm("_binary_test_jpeg_end");

namespace {
State currentState = State::Idle;
constexpr size_t MaxCardImageBytes = 40 * 1024;

const char* stateName(State state)
{
    switch (state) {
    case State::Display:
        return "DISPLAY";
    case State::Collection:
        return "COLLECTION";
    case State::Cam:
        return "CAM";
    case State::CardInfo:
        return "CARD_INFO";
    case State::CardImage:
        return "CARD_IMAGE";
    case State::CardRemove:
        return "CARD_REMOVE";
    case State::Idle:
    default:
        return "IDLE";
    }
}

// image -> OCR server (card name) -> Scryfall -> collection
bool addCardFromImage(const uint8_t* image, size_t imageLength)
{
    char cardName[128];
    if (!imageRecognitionGetCardName(image, imageLength, cardName, sizeof(cardName))) {
        printf("Add card: could not read a card name from the image\n");
        return false;
    }
    printf("Add card: recognised \"%s\"\n", cardName);

    char* cardJson = apiFetchCardByName(cardName);
    if (cardJson == nullptr) {
        printf("Add card: Scryfall lookup failed for \"%s\"\n", cardName);
        return false;
    }

    const DataResult result = dataAddCard(cardJson);
    apiFreeJson(cardJson);
    if (result == DataResult::AlreadyExists) {
        printf("Add card: \"%s\" is already in the collection\n", cardName);
        return true;
    }
    if (result != DataResult::Ok) {
        printf("Add card: could not store the card (error %d)\n", static_cast<int>(result));
        return false;
    }
    printf("Add card: \"%s\" added to the collection\n", cardName);
    return true;
}

// Card number -> collection data -> screen.
void sendCardInfo(int index)
{
    char* cardJson = dataGetCardDetail(index);
    if (cardJson == nullptr || !displayCommunicationSendCardInfo(cardJson)) {
        printf("Card info: could not send card %d\n", index);
        displayCommunicationSendCardInfoFailed();
    }
    dataFreeJson(cardJson);
}

// Card number -> remove from the collection -> tell the screen.
void removeCard(int index)
{
    const DataResult result = dataDeleteCardByIndex(index);
    if (result != DataResult::Ok) {
        printf("Remove card: could not remove card %d (error %d)\n", index,
               static_cast<int>(result));
    } else {
        printf("Remove card: card %d removed\n", index);
    }
    if (!displayCommunicationSendCardRemoveResult(result == DataResult::Ok)) {
        printf("Failed to send remove card result\n");
    }
}

// Card number -> thumbnail URL -> download -> screen.
void sendCardImage(int index)
{
    char* url = dataGetCardThumbUrl(index);
    size_t imageLength = 0;
    uint8_t* image =
        url != nullptr ? apiFetchBinary(url, MaxCardImageBytes, &imageLength) : nullptr;
    if (image == nullptr || !displayCommunicationSendCardImage(image, imageLength)) {
        printf("Card image: could not send image of card %d\n", index);
        displayCommunicationSendCardImageFailed();
    } else {
        printf("Card image: sent %u bytes\n", static_cast<unsigned>(imageLength));
    }
    apiFreeBinary(image);
    dataFreeJson(url);
}
}

void stateMachineInit()
{
    currentState = State::Idle;
}

void stateMachineRun()
{
    bool receivedCommand = false;
    bool addCardRequested = false;

    if (displayCommunicationHasData()) {
        const DisplayRequest request = displayCommunicationReadRequest();
        currentState = request == DisplayRequest::Cam
                           ? State::Cam
                           : request == DisplayRequest::Collection
                                 ? State::Collection
                                 : request == DisplayRequest::Display
                                       ? State::Display
                                       : request == DisplayRequest::CardInfo
                                             ? State::CardInfo
                                             : request == DisplayRequest::CardImage
                                                   ? State::CardImage
                                                   : request == DisplayRequest::CardRemove
                                                         ? State::CardRemove
                                                         : State::Idle;
        addCardRequested = request == DisplayRequest::Cam;
        receivedCommand = true;
    } else if (camCommunicationHasData()) {
        currentState = State::Cam;
        camCommunicationHandle();
        receivedCommand = true;
    }

    if (receivedCommand) {
        if (addCardRequested) {
            // For now the camera is skipped: the embedded test image is used.
            // The screen shows LOADING until it gets the result back.
            const bool added = addCardFromImage(
                testImageStart, static_cast<size_t>(testImageEnd - testImageStart));
            if (!displayCommunicationSendAddCardResult(added)) {
                printf("Failed to send add card result\n");
            }
        }
        if (currentState == State::CardInfo) {
            sendCardInfo(displayCommunicationReadArgument());
        } else if (currentState == State::CardImage) {
            sendCardImage(displayCommunicationReadArgument());
        } else if (currentState == State::CardRemove) {
            removeCard(displayCommunicationReadArgument());
        }
        if (currentState == State::Collection) {
            char* collectionList = dataGetCardNamesAndColors();
            if (collectionList == nullptr ||
                !displayCommunicationSendCollectionList(collectionList)) {
                printf("Failed to send collection list\n");
            } else {
                printf("Collection list sent to display\n");
            }
            dataFreeJson(collectionList);
        }
        printf("Current state: %s\n", stateName(currentState));
        currentState = State::Idle;
    }
}
