#pragma once

enum class State {
    Idle,
    Display,
    Collection,
    Cam,
    CardInfo,
    CardImage,
    CardRemove
};

void stateMachineInit();
void stateMachineRun();
